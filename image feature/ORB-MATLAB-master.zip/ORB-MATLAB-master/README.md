# ORB-MATLAB 

## Oriented FAST and rotated BRIEF (ORB), MATLAB version
This is a MATLAB version of ORB. It is standalone version, so no prerequisite is needed. 

## Example

main.m - an example of image registration using ORB & homography transform.  
orb.m - code for extracted feature coordinates and their descriptors
